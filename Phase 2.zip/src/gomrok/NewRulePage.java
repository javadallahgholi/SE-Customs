package gomrok;
import javax.swing.*;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class NewRulePage {
	
	public static  JTextField  CreateLable(JPanel panel,String name,int Lx,int Ly,int Lwidth,int Lheight,int Tx,int Ty,int Twidth,int Theight){
		
		JLabel Label = new JLabel(name);
        Label.setBounds(Lx, Ly,Lwidth,Lheight);
        panel.add(Label);
        JTextField Text = new JTextField(20);
        Text.setBounds(Tx, Ty,Twidth,Theight);
        panel.add(Text);
        return Text;
	}

    public static void show(boolean exitOnClose) {
       
    	final JFrame frame = new JFrame("درج قانون");
        frame.setSize(250, 600);
        frame.setLocationRelativeTo(null);
        if (exitOnClose)
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel();
        frame.add(panel);
        panel.setBackground(Color.LIGHT_GRAY);
        String approach[] = {"هوایی","زمینی","دریایی"};

        panel.setLayout(null);

        JLabel ministryLabel = new JLabel("تمامی اظهار نامه هایی که ");
        ministryLabel.setBounds(100, 10, 350, 25);
        panel.add(ministryLabel);

        JTextField fromDateText = CreateLable(panel, "از تاریخ",            150, 40, 350, 25, 30, 40, 100, 25);
        JTextField toDateText = CreateLable(panel, "تا تاریخ",              150, 70, 350, 25, 30, 70, 100, 25);
        JTextField fromUnitPriceText = CreateLable(panel, "از قیمت واحد",    150, 100, 350, 25, 30, 100, 100, 25);
        JTextField toUnitPriceText = CreateLable(panel, "تا قیمت واحد",       150, 130, 350, 25, 30, 130, 100, 25);
        JTextField fromUnitWeightText = CreateLable(panel, "از وزن واحد",    150, 160, 350, 25, 30, 160, 100, 25);
        JTextField toUnitWeightText = CreateLable(panel, "تا وزن واحد",      150, 190, 350, 25, 30, 190, 100, 25);
        JTextField consistStuffsText = CreateLable(panel, "شامل کالا های",   150, 220, 350, 25, 30, 220, 100, 25);
        JTextField fromCompaniesText = CreateLable(panel, "از شرکت های",    150, 250, 350, 25, 30, 250, 100, 25);
        JTextField licencesText = CreateLable(panel, "دارای مجوز های",          150, 300, 350, 25, 30, 300, 100, 25);        

        JLabel endText = new JLabel("می توانند وارد کشور شوند.");
        endText.setBounds(100, 340, 400, 25);
        panel.add(endText);

        JLabel azRahaye = new JLabel("از راه های");
        azRahaye.setBounds(150, 370, 100, 25);
        panel.add(azRahaye);
        JComboBox azRahayeBox = new JComboBox(approach);
        azRahayeBox.setBounds(30, 370, 100 ,25);
        panel.add(azRahayeBox);
        
        JButton registerButton = new JButton("ثبت قانون");
        registerButton.setBounds(120, 420, 75, 25);
        panel.add(registerButton);
        
        JButton exitButton = new JButton("خروج");
        exitButton.setBounds(35, 420, 75, 25);
        panel.add(exitButton);
        
        exitButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                frame.dispose();     
                }
        });

        registerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	frame.dispose();
            }
        });
   
        frame.setVisible(true);
    }
    
}
