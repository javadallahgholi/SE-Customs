package gomrok;

import java.io.Serializable;
import java.util.Set;

public class Ezharname implements Serializable {
	
	private static final long serialVersionUID = 1L;
	private int id;
	private String Date;
	private String TajerName;
	private String TajerLastname;
	private int TajerNationalID;
	private int Quantity;
	private int TotalPriceOFStuffs;
	private MasulGomrok MasulGomrok;
	private Set<License> License;
	private Set<Stuff> Stuff;
	
	public Ezharname(){};
	
	public Ezharname(String _Date,String _TajerName,String _TajerLastname,int _TajerNationalID,int _Quantity, int _TotalPriceOFStuffs) {
		
		Date = _Date;
		TajerName = _TajerName;
		TajerLastname = _TajerLastname;
		TajerNationalID = _TajerNationalID;
		Quantity = _Quantity;
		TotalPriceOFStuffs = _TotalPriceOFStuffs;
		
	}

	public int getTotalPriceOFStuffs() {
		return TotalPriceOFStuffs;
	}

	public void setTotalPriceOFStuffs(int totalPriceOFStuffs) {
		TotalPriceOFStuffs = totalPriceOFStuffs;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDate() {
		return Date;
	}

	public void setDate(String date) {
		Date = date;
	}

	public String getTajerName() {
		return TajerName;
	}

	public void setTajerName(String tajerName) {
		TajerName = tajerName;
	}

	public String getTajerLastname() {
		return TajerLastname;
	}

	public void setTajerLastname(String tajerLastname) {
		TajerLastname = tajerLastname;
	}

	public int getTajerNationalID() {
		return TajerNationalID;
	}

	public void setTajerNationalID(int tajerNationalID) {
		TajerNationalID = tajerNationalID;
	}

	public int getQuantity() {
		return Quantity;
	}

	public void setQuantity(int quantity) {
		Quantity = quantity;
	}

	public MasulGomrok getMasulGomrok() {
		return MasulGomrok;
	}

	public void setMasulGomrok(MasulGomrok masulGomrok) {
		MasulGomrok = masulGomrok;
	}

	public Set<License> getLicense() {
		return License;
	}

	public void setLicense(Set<License> license) {
		License = license;
	}
	
	
	public Set<Stuff> getStuff() {
		return Stuff;
	}

	public void setStuff(Set<Stuff> stuff) {
		Stuff = stuff;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
}
