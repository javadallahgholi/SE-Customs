package gomrok;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Operations {
	
     public static int compareDate(String d1, String d2) {
    	try{
    		
    		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
        	Date date1 = sdf.parse(d1);
        	Date date2 = sdf.parse(d2);
        	
        	if(date1.compareTo(date2)>0)
        		return 1;
        	else if(date1.compareTo(date2)<0)
        		return -1;
        	else if(date1.compareTo(date2)==0)
        		return 0;
        	
    	}catch(ParseException ex){
    		ex.printStackTrace();
    	}
    	return 10000;
    }
     public static String[] splitter(String s){

    	 String delimeter = "[-]";
    	 return s.split(delimeter);

     }
}