package gomrok;

public class Rule {

	private int id;
	private String FromDate;
	private String ToDate;
	private int FromTotalPrice;
	private int ToTotalPrice;
	private int ToUnitPrice;
	private int ToTotalWeight;
	private int FromTotalWeight;
	private String Stuffs;
	private String Companies;
	private int ApproachID;
	private int Mojavez;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getFromDate() {
		return FromDate;
	}
	public void setFromDate(String fromDate) {
		FromDate = fromDate;
	}
	public String getToDate() {
		return ToDate;
	}
	public void setToDate(String toDate) {
		ToDate = toDate;
	}
	public int getFromTotalPrice() {
		return FromTotalPrice;
	}
	public void setFromTotalPrice(int fromTotalPrice) {
		FromTotalPrice = fromTotalPrice;
	}
	public int getToTotalPrice() {
		return ToTotalPrice;
	}
	public void setToTotalPrice(int toTotalPrice) {
		ToTotalPrice = toTotalPrice;
	}
	public int getToUnitPrice() {
		return ToUnitPrice;
	}
	public void setToUnitPrice(int toUnitPrice) {
		ToUnitPrice = toUnitPrice;
	}
	public int getToTotalWeight() {
		return ToTotalWeight;
	}
	public void setToTotalWeight(int toTotalWeight) {
		ToTotalWeight = toTotalWeight;
	}
	public int getFromTotalWeight() {
		return FromTotalWeight;
	}
	public void setFromTotalWeight(int fromTotalWeight) {
		FromTotalWeight = fromTotalWeight;
	}
	public String getStuffs() {
		return Stuffs;
	}
	public void setStuffs(String stuffs) {
		Stuffs = stuffs;
	}
	public String getCompanies() {
		return Companies;
	}
	public void setCompanies(String companies) {
		Companies = companies;
	}
	public int getApproachID() {
		return ApproachID;
	}
	public void setApproachID(int approachID) {
		ApproachID = approachID;
	}
	public int getMojavez() {
		return Mojavez;
	}
	public void setMojavez(int mojavez) {
		Mojavez = mojavez;
	}
		
}
