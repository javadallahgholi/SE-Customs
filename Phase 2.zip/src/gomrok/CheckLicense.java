package gomrok;

import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.Vector;

import org.hibernate.Session;

public class CheckLicense {
	
	public static boolean check(Ezharname e, Stuff s, Rule r){
		
		String[] stuffs = Operations.splitter(r.getStuffs());
		boolean stuffFlag = false;
		
		for(int i = 0; i < stuffs.length ; i++){
			if(stuffs[i].equals(s.getStuffName()))
				stuffFlag = true;
		}
		
		if(Operations.compareDate(e.getDate(), r.getFromDate())==-1 || Operations.compareDate(e.getDate(), r.getFromDate())==1)
			return false;
		if(s.getUnitPrice() <= r.getFromTotalPrice() || s.getUnitPrice() >= r.getToTotalPrice())
			return false;
		if(s.getWeight() <= r.getFromTotalWeight() || s.getWeight() >= r.getToTotalWeight())
			return false;
		if(!stuffFlag)
			return false;
		if( r.getApproachID() != s.getApproachID())
			return false;
		if(!(s.getCompanyName().equals(r.getCompanies())))
			return false;
		
		return true;
		
	}
	
	public static Vector<Integer> GetLicense(Ezharname e){
		
		Vector<Integer> LicID = null;
		Set<Stuff> a = new HashSet<Stuff>();
		a = e.getStuff();
		Session session=DBConnection.CreateSession();
		List<Rule> l=session.createCriteria(Rule.class).list();
		
		for(Iterator<Stuff> it= a.iterator(); it.hasNext();){
			for(int j=0;j<l.size();j++)
				if(check(e,it.next(),l.get(j)))
					LicID.add(l.get(j).getMojavez());

		}
		
		return LicID;
		
	}

}