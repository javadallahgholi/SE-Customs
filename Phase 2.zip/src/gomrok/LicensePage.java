package gomrok;

import javax.swing.*;
import javax.swing.colorchooser.ColorSelectionModel;

import org.hibernate.Session;
import org.w3c.dom.css.RGBColor;

import java.awt.Color;
import java.awt.MultipleGradientPaint.ColorSpaceType;
import java.awt.color.ColorSpace;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.RGBImageFilter;


public class LicensePage{

	public static  JTextField  CreateLable(JPanel panel,String name,int Lx,int Ly,int Lwidth,int Lheight,int Tx,int Ty,int Twidth,int Theight){
		
		JLabel Label = new JLabel(name);
        Label.setBounds(Lx, Ly,Lwidth,Lheight);
        panel.add(Label);
        JTextField Text = new JTextField(20);
        Text.setBounds(Tx, Ty,Twidth,Theight);
        panel.add(Text);
        return Text;
	}
	
    public static void show(boolean exitOnClose) {

		String approach[]={"هوایی","زمینی","دریایی"};

		
    	final JFrame frame = new JFrame("فرم صدور مجوز");
        frame.setSize(750, 500);
        frame.setLocationRelativeTo(null);
        if (exitOnClose)
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel();
        frame.add(panel);
        panel.setBackground(Color.LIGHT_GRAY);
        ImageImplement logo2 = new ImageImplement(new ImageIcon("logo2.png").getImage());
        panel.add(logo2);
        logo2.setLocation(20, 15);
        ImageImplement logo3 = new ImageImplement(new ImageIcon("logo3.png").getImage());
        panel.add(logo3);
        logo3.setLocation(650, 20);
        panel.setLayout(null);

        JLabel Gomrok = new JLabel(" گمرک ایران ");
        Gomrok.setBounds(27, 95,100,25);
        
        panel.add(Gomrok);
        final JTextField idlicenseText = CreateLable(panel, "شناسه اظهار نامه :",            390, 100, 100, 25, 250, 100, 125, 25);
        final JTextField startDateLicenseText = CreateLable(panel, "تاریخ ثبت مجوز :",      520, 140, 100, 25, 380, 140, 125, 25);
        final JTextField finishDateLicenseText = CreateLable(panel, "تاریخ اتمام مجوز :",     285, 140, 150, 25, 150, 140, 125, 25);
        final JTextField stuffNameText = CreateLable(panel, "نام کالا :",                 520, 180, 150, 25, 380, 180, 125, 25);
        final JTextField numberStuffText = CreateLable(panel, "تعداد کالا :",              285, 180, 150, 25, 150, 180, 125, 25);
        final JTextField unitPriceText = CreateLable(panel, "قیمت واحد :",                520, 220, 150, 25, 380, 220, 125, 25);
        final JTextField unitWeightText = CreateLable(panel, "وزن واحد :",               285, 220, 150, 25, 150, 220, 125, 25);
        final JTextField companyText = CreateLable(panel, "از شرکت :",                  520, 260, 150, 25, 380, 260, 125, 25);
        final JTextField countryText = CreateLable(panel, "از کشور :",                   285, 260, 150, 25, 150, 260, 125, 25);
        
        JLabel approachLabel = new JLabel("نحوه ورود به کشور");
        approachLabel.setBounds(360, 325, 150, 25);
        panel.add(approachLabel);
        final JComboBox approachBox = new JComboBox(approach);
        approachBox.setBounds(250, 325,90,20);
        panel.add(approachBox);

        
        JButton registerButton = new JButton("ثبت مجوز");
        registerButton.setBounds(380, 400, 150, 25);
        panel.add(registerButton);

        JButton exitButton = new JButton("خروج");
        exitButton.setBounds(210, 400, 150, 25);
        panel.add(exitButton);
        
        registerButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                
            	License l = new License(startDateLicenseText.getText(), finishDateLicenseText.getText(), stuffNameText.getText(), Integer.parseInt(numberStuffText.getText()), Integer.parseInt(unitPriceText.getText()), Integer.parseInt(unitWeightText.getText()), companyText.getText(), countryText.getText());
            	Session session=DBConnection.CreateSession();
            	Ezharname ez=(Ezharname)session.get(Ezharname.class, Integer.parseInt(idlicenseText.getText()));
            	l.setEzharname(ez);
            	DBConnection.Insert(l);
                }
        });
        
        exitButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                frame.dispose();     
                }
        });
        frame.setVisible(true);


    }
}