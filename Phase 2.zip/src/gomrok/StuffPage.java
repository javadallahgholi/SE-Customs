package gomrok;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.WindowConstants;

import org.hibernate.Session;



public class StuffPage {
	
	public static  JTextField  CreateLable(JPanel panel,String name,int Lx,int Ly,int Lwidth,int Lheight,int Tx,int Ty,int Twidth,int Theight){
			
			JLabel Label = new JLabel(name);
	        Label.setBounds(Lx, Ly,Lwidth,Lheight);
	        panel.add(Label);
	        JTextField Text = new JTextField(20);
	        Text.setBounds(Tx, Ty,Twidth,Theight);
	        panel.add(Text);
	        return Text;
		}
	
	public static void show(boolean exitOnClose,int EzharnameID) {

			String approach[]={"هوایی","زمینی","دریایی"};
		
	        final JFrame frame = new JFrame("وارد کردن اطلاعات");
	        frame.setSize(550, 400);
	        frame.setLocationRelativeTo(null);
	        if (exitOnClose)
	            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	
	        JPanel panel = new JPanel();
	        frame.add(panel);
	        panel.setBackground(Color.LIGHT_GRAY);
	        panel.setLayout(null);
	        
	        final JTextField stuffNameText = CreateLable(panel, "نام کالا :",       440, 20, 330, 25, 275, 20, 150, 25);
	        final JTextField quantityText = CreateLable(panel, "تعداد کالا :", 200, 20, 350, 25, 35, 20, 150, 25);
	        final JTextField weightText = CreateLable(panel, "وزن واحد کالا :",         440, 95, 350, 25, 275, 95, 150, 25);
	        final JTextField unitPriceText = CreateLable(panel, "قیمت واحد :",       200, 95, 350, 25, 35, 95, 150, 25);
	        final JTextField companyText = CreateLable(panel, "شرکت سازنده :",     440, 170, 350, 25, 275, 170, 150, 25);
	        final JTextField countryText = CreateLable(panel, "کشور مبدا :",     200, 170, 350, 25, 35, 170, 150, 25);
	        
	        JLabel approachLabel = new JLabel("نحوه ورود به کشور");
	        approachLabel.setBounds(150, 245, 150, 25);
	        panel.add(approachLabel);
	        final JComboBox approachBox = new JComboBox(approach);
	        approachBox.setBounds(50, 245,90,20);
	        panel.add(approachBox);
	        
	        JButton submitButton = new JButton("اضافه کردن");
	        submitButton.setBounds(270, 310, 120, 25);
	        panel.add(submitButton);
	        
	        JButton exitButton = new JButton("خروج");
	        exitButton.setBounds(130, 310, 120, 25);
	        panel.add(exitButton);
	        
	        exitButton.addActionListener(new ActionListener() {
	            public void actionPerformed(ActionEvent e) {
	                frame.dispose();     
	                }
	        });
	        
	        submitButton.addActionListener(new ActionListener() {
	
	            public void actionPerformed(ActionEvent e) {
	            	
	        		Stuff s = new Stuff(stuffNameText.getText(),Integer.parseInt(quantityText.getText()),Integer.parseInt(weightText.getText()),Integer.parseInt(unitPriceText.getText()), companyText.getText(), countryText.getText(), approachBox.getSelectedIndex());
	        		Session session=DBConnection.CreateSession();
	        		Ezharname ez=(Ezharname)session.get(Ezharname.class, EzharnameID);
	        		s.setEzharname(ez);
	        		DBConnection.Insert(s);
	        		
	        		Vector<Integer> a=null;
	        		a=CheckLicense.GetLicense(ez);
	        		for(int i=0;i<a.size();i++)
	        			System.out.println(a.get(i));
	            }
	        });
	    
	        submitButton.addActionListener(new ActionListener() {
	
	            public void actionPerformed(ActionEvent e) {
	            	frame.dispose();
	            }
	        });
	
	        frame.setVisible(true);
	        frame.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
	  
	    }
}
