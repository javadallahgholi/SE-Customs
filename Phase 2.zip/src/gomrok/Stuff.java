package gomrok;

public class Stuff {
	
	private int id;
	private String StuffName;
	private int Quantity;
	private int Weight;
	private int UnitPrice;
	private String CompanyName;
	private String SourceCountry;
	private int ApproachID;
	private Ezharname Ezharname;
	
	public Stuff(String _StuffName, int _Quantity, int _Weight, int _UnitPrice, String _CompanyName, String _SourceCountry, int _ApproachID){
		
		StuffName = _StuffName;
		Quantity = _Quantity;
		Weight = _Weight;
		UnitPrice = _UnitPrice;
		CompanyName = _CompanyName;
		SourceCountry = _SourceCountry;
		ApproachID = _ApproachID;
		
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getStuffName() {
		return StuffName;
	}

	public void setStuffName(String stuffName) {
		StuffName = stuffName;
	}

	public int getQuantity() {
		return Quantity;
	}

	public void setQuantity(int quantity) {
		Quantity = quantity;
	}

	public int getWeight() {
		return Weight;
	}

	public void setWeight(int weight) {
		Weight = weight;
	}

	public int getUnitPrice() {
		return UnitPrice;
	}

	public void setUnitPrice(int unitPrice) {
		UnitPrice = unitPrice;
	}

	public String getCompanyName() {
		return CompanyName;
	}

	public void setCompanyName(String companyName) {
		CompanyName = companyName;
	}

	public String getSourceCountry() {
		return SourceCountry;
	}

	public void setSourceCountry(String sourceCountry) {
		SourceCountry = sourceCountry;
	}

	public int getApproachID() {
		return ApproachID;
	}

	public void setApproachID(int approachID) {
		ApproachID = approachID;
	}

	public Ezharname getEzharname() {
		return Ezharname;
	}

	public void setEzharname(Ezharname ezharname) {
		Ezharname = ezharname;
	}
	
}