package gomrok;




public class Main {

    public static void main(String[] args) {
    	
    	Loginpage.show(true);
    	//LicensePage.show(true);
    	//NewRulePage.show(true);
    	//EzharNamehPage.show(true);
    	//StuffPage.show(true);
    	//VezaratMasoulPage.show(true);
    	//GomrokMasoulPage.show(true);
    }
    
    
    private static void loginTest() {
        new Loginpage();
        Loginpage.show(true);
    
    }
    
    
}