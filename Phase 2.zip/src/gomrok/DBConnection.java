package gomrok;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

public class DBConnection {
	
	public static Session CreateSession(){
		
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		
		return session;
	}
	
	public static void CloseSession(Session session){
		
		session.close();
	}
	
	public static <T> void Insert(T istance){
		
		Session session = CreateSession();
		session.save(istance);
		session.getTransaction().commit();
		CloseSession(session);
		
	}
		
}