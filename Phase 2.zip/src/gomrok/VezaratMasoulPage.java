package gomrok;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.WindowConstants;

public class VezaratMasoulPage {
	
	public static void ShowLicensePage(){
		
			LicensePage.show(false);
		}
	
	public static  JTextField  CreateLable(JPanel panel,String name,int Lx,int Ly,int Lwidth,int Lheight,int Tx,int Ty,int Twidth,int Theight){
			
			JLabel Label = new JLabel(name);
	        Label.setBounds(Lx, Ly,Lwidth,Lheight);
	        panel.add(Label);
	        JTextField Text = new JTextField(20);
	        Text.setBounds(Tx, Ty,Twidth,Theight);
	        panel.add(Text);
	        return Text;
		}
	
	public static void show(boolean exitOnClose) {
	    	
	        final JFrame frame = new JFrame("پنل کاربری مسئول وزارت خانه");
	        frame.setSize(500, 300);
	        frame.setLocationRelativeTo(null);
	        if (exitOnClose)
	            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	
	        JPanel panel = new JPanel();
	        frame.add(panel);
	        panel.setBackground(Color.LIGHT_GRAY);
	        panel.setLayout(null);
	        
	        JButton enterButton = new JButton("صدور مجوز");
	        enterButton.setBounds(260, 120, 150, 25);
	        panel.add(enterButton);
	        
	        JButton exitButton = new JButton("خروج");
	        exitButton.setBounds(80, 120, 150, 25);
	        panel.add(exitButton);
	        
	        exitButton.addActionListener(new ActionListener() {
	            public void actionPerformed(ActionEvent e) {
	                frame.dispose();     
	                }
	        });
	        
	        enterButton.addActionListener(new ActionListener() {
	            @Override
	            public void actionPerformed(ActionEvent e) {
	            	
	            	ShowLicensePage();
	            }
	        });
	        
	        frame.setVisible(true);
	  
	    }

}
