package gomrok;

import javax.swing.*;

import org.hibernate.Query;
import org.hibernate.Session;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class EzharNamehPage {
	
	public static  JTextField  CreateLable(JPanel panel,String name,int Lx,int Ly,int Lwidth,int Lheight,int Tx,int Ty,int Twidth,int Theight){
		
		JLabel Label = new JLabel(name);
        Label.setBounds(Lx, Ly,Lwidth,Lheight);
        panel.add(Label);
        JTextField Text = new JTextField(20);
        Text.setBounds(Tx, Ty,Twidth,Theight);
        panel.add(Text);
        return Text;
	}
	
    public static void show(boolean exitOnClose) {
    	
    	final JFrame frame = new JFrame("فرم اظهارنامه گمرک");
        frame.setSize(800, 350);
        frame.setLocationRelativeTo(null);
        
        if (exitOnClose)
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel();
        frame.add(panel);
        panel.setBackground(Color.LIGHT_GRAY);
        ImageImplement img = new ImageImplement(new ImageIcon("logo2.png").getImage());
        panel.add(img);
        img.setLocation(25, 15);

        JLabel Gomrok = new JLabel(" گمرک ");
        Gomrok.setBounds(120, 15,100,25);
        panel.add(Gomrok);
        JLabel Gomrok1 = new JLabel(" جمهوری اسلامی ");
        Gomrok1.setBounds(100, 35,100,25);
        panel.add(Gomrok1);
        JLabel Gomrok2 = new JLabel(" ایران ");
        Gomrok2.setBounds(120, 55,100,25);
        panel.add(Gomrok2);
        
        panel.setLayout(null);

        final JTextField dateText = CreateLable(panel, "تاریخ  ثبت اظهارنامه",           665, 40, 100, 25, 525, 40, 100, 25);
        final JTextField tajerNameText = CreateLable(panel, "نام تاجر",           690, 120, 80, 25, 525, 120, 100, 25);
        final JTextField tajerLastText = CreateLable(panel, "نام خانوادگی تاجر",       395, 120, 150, 25, 280, 120, 100, 25);
        final JTextField tajerNationalIdText = CreateLable(panel, "شناسه ملی تاجر",  150, 120, 150, 25, 35, 120, 100, 25);
        final JTextField quantityText = CreateLable(panel, "تعداد کالا",            395, 180, 150, 25, 280, 180, 100, 25);
        final JTextField totalPriceText = CreateLable(panel, "قیمت کل کالا ها",       690, 180, 80, 25, 525, 180, 100, 25);

        JButton registerButton = new JButton("ثبت و وارد کردن کالا");
        registerButton.setBounds(420, 245, 150, 25);
        panel.add(registerButton);
        
        JButton exitButton = new JButton("خروج");
        exitButton.setBounds(240, 245, 150, 25);
        panel.add(exitButton);
        
        exitButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                frame.dispose();     
                }
        });
                  
        registerButton.addActionListener(new ActionListener() {
        	
            public void actionPerformed(ActionEvent e) {
            	
            	frame.dispose();
            	Ezharname ezh = new Ezharname(dateText.getText(), tajerNameText.getText(), tajerLastText.getText(), Integer.parseInt(tajerNationalIdText.getText()), Integer.parseInt(quantityText.getText()), Integer.parseInt(totalPriceText.getText()));
            	Session session=DBConnection.CreateSession();
            	MasulGomrok m = (MasulGomrok)session.get(MasulGomrok.class, 1);
            	ezh.setMasulGomrok(m);
            	DBConnection.Insert(ezh);
            	
            	int number = Integer.parseInt(quantityText.getText());
                for(int i=0;i<number;i++)
                	StuffPage.show(true,1);
            	
            }
        });
        registerButton.addActionListener(new ActionListener() {
        	
            public void actionPerformed(ActionEvent e) {
            	frame.dispose();
            }
        });

        frame.setVisible(true);
    }

}