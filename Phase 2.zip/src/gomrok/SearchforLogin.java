package gomrok;

import java.util.Iterator;
import java.util.List;
import java.util.Vector;

import org.hibernate.Query;
import org.hibernate.Session;

public class SearchforLogin {

	public static int Search(String Username,String Password){
		
		boolean FindUserFlag=false;
		int LoginType=-1;
		
		Session session = DBConnection.CreateSession();
		Query q = session.createQuery("FROM Logininfo");
	    List list = ((org.hibernate.Query) q).list();
	   
	    if(list.size() != 0){
	    	
		      Iterator it = list.iterator();
		      while(it.hasNext()) {
		    	  
		    	Logininfo li = (Logininfo)it.next();
		        if(li.getUserName().equals(Username) && li.getPassword().equals(Password)){
			        	FindUserFlag=true;
			        	LoginType = li.getLoginType();
		        	}
		      }
	    }
	    else System.out.println("No records exist");
		
	    if(FindUserFlag == true && LoginType==1){
	    	//GomrokMasoulPage gmp = new GomrokMasoulPage();
	    	//gmp.show(FindUserFlag);
	    	return 1;
	    }
	    
	    else if(FindUserFlag == true && LoginType==2)
	    	return 2;
	    	//VezaratMasoulPage.show(FindUserFlag);
	    	
	    
	    else
	    	return 0;
	    	//LoginErrorPage.ShowLoginErrorPage();
	}
		
	
}