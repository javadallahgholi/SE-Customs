package gomrok;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class LoginErrorPage {

public static void ShowLoginErrorPage(){
		
		final JFrame eframe = new JFrame("خطا");
        eframe.setSize(210, 210);
        eframe.setLocationRelativeTo(null);
        JPanel epanel = new JPanel();
        eframe.add(epanel);
        epanel.setLayout(null);
        
        JLabel errorLabel = new JLabel("شناسه کاربری یا رمز عبور اشتباه می باشد !");
        errorLabel.setBounds(5, 40, 350, 25);
        epanel.add(errorLabel);
        
        JButton okButton = new JButton("سعی مجدد");
        okButton.setBounds(40, 100, 100, 25);
        epanel.add(okButton);
        
        okButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                eframe.dispose();     
                }
        });     
        eframe.setVisible(true);
	}
	
}
