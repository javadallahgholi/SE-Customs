package gomrok;
import javax.swing.*;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class GomrokMasoulPage {
	
	public static void ShowRulesPage(){
		
		NewRulePage.show(false);
	}
	
	public static void ShowEzharnamePage(){
		
		EzharNamehPage.show(false);
	}
	
	public static void show(boolean exitOnClose) {
	    	
	        final JFrame frame = new JFrame("پنل کاربری مسئول وزارت خانه");
	        frame.setSize(500, 300);
	        frame.setLocationRelativeTo(null);
	        if (exitOnClose)
	            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	
	        JPanel panel = new JPanel();
	        frame.add(panel);
	        panel.setBackground(Color.LIGHT_GRAY);
	        panel.setLayout(null);

	        JButton EzharNamehPorKardan = new JButton("بر کردن اظهار نامه");
	        EzharNamehPorKardan.setBounds(80, 80, 150, 25);
	        panel.add(EzharNamehPorKardan);
	        
	        EzharNamehPorKardan.addActionListener(new ActionListener() {
	            @Override
	            public void actionPerformed(ActionEvent e) {
	                
	            	ShowEzharnamePage();

	            }
	        });
	        JButton ghanunSodur = new JButton("صدور قانون");
	        ghanunSodur.setBounds(260, 80, 150, 25);
	        panel.add(ghanunSodur);
	        
	        ghanunSodur.addActionListener(new ActionListener() {
	            @Override
	            public void actionPerformed(ActionEvent e) {
	            	
	            	ShowRulesPage();
	            }
	        });
	        
	        JButton exitButton = new JButton("خروج");
	        exitButton.setBounds(165, 170, 150, 25);
	        panel.add(exitButton);
	        
	        exitButton.addActionListener(new ActionListener() {
	            public void actionPerformed(ActionEvent e) {
	                frame.dispose();     
	                }
	        });
	    
	        frame.setVisible(true);
	  
	    }

}