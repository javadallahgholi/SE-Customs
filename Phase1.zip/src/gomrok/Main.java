package gomrok;

public class Main {
	
	private static void ShowLoginPage() {
        Loginpage newLogin = new Loginpage();
        newLogin.show(true);
    
    }
	
    public static void main(String[] args) {
    	ShowLoginPage();
    }

}
