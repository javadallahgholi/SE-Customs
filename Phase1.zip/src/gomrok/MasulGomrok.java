package gomrok;

public class MasulGomrok {
	
	int PersonnelID;
	String FirstName;
	String LastName;
	String Post;
	public int getPersonnelID() {
		return PersonnelID;
	}
	public void setPersonnelID(int personnelID) {
		PersonnelID = personnelID;
	}
	public String getFirstName() {
		return FirstName;
	}
	public void setFirstName(String firstName) {
		FirstName = firstName;
	}
	public String getLastName() {
		return LastName;
	}
	public void setLastName(String lastName) {
		LastName = lastName;
	}
	public String getPost() {
		return Post;
	}
	public void setPost(String post) {
		Post = post;
	}
	
	
	
}
