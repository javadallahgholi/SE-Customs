package gomrok;

/**
 * Created by hossein on 2/15/16.
 */
public class ProductInformationFormCreator {

    public static final String[] labels = { "نام کالا", "نام شرکت", "وزن کالا", "تعداد کالا", "قیمت واحد" };
    public static final int[] lengths = { 15, 15, 15, 15, 15 };

    public static SimpleForm createProductInformationForm() {
        return new SimpleForm(labels, lengths);
    }
}
