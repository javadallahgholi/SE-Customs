package gomrok;

import org.hibernate.Query;
import javax.swing.*;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Iterator;


public class Loginpage {
	
	public static void ShowLoginErrorPage(){
		
		JFrame eframe = new JFrame("خطا");
        eframe.setSize(200, 200);
     
        JPanel epanel = new JPanel();
        eframe.add(epanel);
       epanel.setLayout(null);
       
        JLabel errorLabel = new JLabel("شناسه کاربری یا رمز عبور اشتباه می باشد !");
        errorLabel.setBounds(5, 40, 350, 25);
        epanel.add(errorLabel);
        
        
        JButton okButton = new JButton("سعی مجدد");
        okButton.setBounds(40, 100, 100, 25);
        epanel.add(okButton);
        
        okButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent e) {

                eframe.dispose();     
                }
        });     
        eframe.setVisible(true);
	}
	
	public static void showNextPage(String Username,String Password,Session session){
		
		boolean FindUserFlag=false;
		Query q = session.createQuery("FROM Logininfo");
	    List list = ((org.hibernate.Query) q).list();
	   
	    if(list.size() != 0){
	    	
		      Iterator it = list.iterator();
		      while(it.hasNext()) {
		    	  
		    	Logininfo li = (Logininfo)it.next();
		        if(li.getUserName().equals(Username) && li.getPassword().equals(Password))
		        	FindUserFlag=true;
		      }
	    }
	    else System.out.println("No records exist");
		
	    if(FindUserFlag == true){
	    	GomrokMasoulPage gmp = new GomrokMasoulPage();
	    	gmp.show(FindUserFlag);
	    }
	    
	    else ShowLoginErrorPage();
		
	}
	
    public static void show(boolean exitOnClose) {
    	
        JFrame frame = new JFrame("صفحه ورود");
        frame.setSize(800, 300);
        if (exitOnClose)
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel();
        frame.add(panel);
        placeComponents(panel);
        frame.setVisible(true);
  
    }
     
    private static void placeComponents(JPanel panel) {
        
    	panel.setLayout(null);
        JLabel userNameLabel = new JLabel("نام کاربری :");
        userNameLabel.setBounds(450, 75, 350, 25);
        panel.add(userNameLabel);
        JTextField userNameText = new JTextField(20);
        userNameText.setBounds(330, 75, 100, 25);
        panel.add(userNameText);

        JLabel passwordLabel = new JLabel("شناسه عبور :");
        passwordLabel.setBounds(450, 125, 80, 25);
        panel.add(passwordLabel);
        JTextField passwordText = new JTextField(20);
        passwordText.setBounds(330, 125, 100, 25);
        panel.add(passwordText);
        
        JButton submitButton = new JButton("ورود");
        submitButton.setBounds(305, 175, 150, 25);
        panel.add(submitButton);

          
        submitButton.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {
            	
                String Username = userNameText.getText();
                userNameText.setText("");  
                String Password = passwordText.getText();
                passwordText.setText("");
                
                SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
        		Session session = sessionFactory.openSession();
        		session.beginTransaction();
        		
        		showNextPage(Username,Password,session);
        	    	
        		session.close();
                
                
            }
        });
    
    }
	
	}