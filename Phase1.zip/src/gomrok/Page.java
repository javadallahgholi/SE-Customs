package gomrok;
/**
 * Created by hossein on 2/17/16.
 */
public abstract class Page {

    public abstract void show(boolean exitOnClose);

}