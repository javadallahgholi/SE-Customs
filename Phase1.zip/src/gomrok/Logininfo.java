package gomrok;

public class Logininfo {
	
	int id;
	String UserName;
	String Password;
	
	Logininfo(){}; 
	
	Logininfo(String u,String p){
		
		UserName=u;
		Password=p;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getUserName() {
		return UserName;
	}
	public void setUserName(String userName) {
		UserName = userName;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}
	
	
}
