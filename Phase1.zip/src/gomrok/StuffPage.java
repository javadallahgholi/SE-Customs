package gomrok;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Iterator;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.WindowConstants;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

public class StuffPage {
public static void show(boolean exitOnClose) {
    	
        JFrame frame = new JFrame("وارد کردن اطلاعات");
        frame.setSize(500, 300);
        if (exitOnClose)
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel();
        frame.add(panel);
        placeComponents(panel);
        frame.setVisible(true);
        frame.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
  
    }
     
    private static void placeComponents(JPanel panel) {
        
    	panel.setLayout(null);
        JLabel stuffNameLabel = new JLabel("نام کالا :");
        stuffNameLabel.setBounds(440, 15, 350, 25);
        panel.add(stuffNameLabel);
        JTextField stuffNameText = new JTextField(20);
        stuffNameText.setBounds(275, 15, 150, 25);
        panel.add(stuffNameText);
        
        JLabel companyNameLabel = new JLabel("نام شرکت :");
        companyNameLabel.setBounds(200, 15, 350, 25);
        panel.add(companyNameLabel);
        JTextField companyNameText = new JTextField(20);
        companyNameText.setBounds(35, 15, 150, 25);
        panel.add(companyNameText);
        
        JLabel weightLabel = new JLabel("وزن کالا :");
        weightLabel.setBounds(440, 75, 350, 25);
        panel.add(weightLabel);
        JTextField weightText = new JTextField(20);
        weightText.setBounds(275, 75, 150, 25);
        panel.add(weightText);
        
        JLabel quantityLabel = new JLabel("تعداد کالا :");
        quantityLabel.setBounds(200, 75, 350, 25);
        panel.add(quantityLabel);
        JTextField quantityText = new JTextField(20);
        quantityText.setBounds(35, 75, 150, 25);
        panel.add(quantityText);
        
        JLabel unitLabel = new JLabel("فیمت واحد :");
        unitLabel.setBounds(300, 140, 350, 25);
        panel.add(unitLabel);
        JTextField unitText = new JTextField(20);
        unitText.setBounds(120, 140, 150, 25);
        panel.add(unitText);
        
        JButton submitButton = new JButton("ورود");
        submitButton.setBounds(170, 200, 150, 25);
        panel.add(submitButton);

        
        submitButton.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {
            	
            	SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
        		Session session = sessionFactory.openSession();
        		session.beginTransaction();
            	
        		Stuff s=new Stuff();
        		s.setStuffName(stuffNameText.getText());
        		s.setCompanyName(companyNameText.getText());
        		s.setNumberOFStuff(Integer.parseInt(quantityText.getText()));
        		s.setWeight(Integer.parseInt(weightText.getText()));
        		s.setUnitPrice(Integer.parseInt(unitText.getText()));
        		
        		session.save(s);
        		session.getTransaction().commit();
        		session.close();
        		
        		
                
            }
        });
    
    }
}
