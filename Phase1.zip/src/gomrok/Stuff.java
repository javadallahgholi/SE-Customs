package gomrok;

public class Stuff {
	
	int id;
	String StuffName;
	String CompanyName;
	int weight;
	int NumberOFStuff;
	int UnitPrice;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getStuffName() {
		return StuffName;
	}
	public void setStuffName(String stuffName) {
		StuffName = stuffName;
	}
	public String getCompanyName() {
		return CompanyName;
	}
	public void setCompanyName(String companyName) {
		CompanyName = companyName;
	}
	public int getWeight() {
		return weight;
	}
	public void setWeight(int weight) {
		this.weight = weight;
	}
	public int getNumberOFStuff() {
		return NumberOFStuff;
	}
	public void setNumberOFStuff(int numberOFStuff) {
		NumberOFStuff = numberOFStuff;
	}
	public int getUnitPrice() {
		return UnitPrice;
	}
	public void setUnitPrice(int unitPrice) {
		UnitPrice = unitPrice;
	}
	
	
}
