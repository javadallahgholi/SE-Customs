package gomrok;


/**
 * Created by j-ghazvne on 2/15/16.
 */
public class ProductInformationGetter {

    public static SimpleForm[] getProductInformationFroms(int quantity) {
        SimpleForm[] productForms;
        productForms = new SimpleForm[quantity];
        for (int i = 0; i < quantity; i++)
            productForms[i] = ProductInformationFormCreator.createProductInformationForm();
        return productForms;
    }
}
