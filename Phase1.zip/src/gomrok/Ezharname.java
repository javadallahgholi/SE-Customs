package gomrok;

public class Ezharname {
	
	int id;
	String Date;
	String TajerName;
	String TajerLastname;
	int TajerNationalID;
	String SourceCountry;
	int Approach;
	int NumberOFStuffs;
	int PriceOFStuffs;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getDate() {
		return Date;
	}
	public void setDate(String date) {
		Date = date;
	}
	public String getTajerName() {
		return TajerName;
	}
	public void setTajerName(String tajerName) {
		TajerName = tajerName;
	}
	public String getTajerLastname() {
		return TajerLastname;
	}
	public void setTajerLastname(String tajerLastname) {
		TajerLastname = tajerLastname;
	}
	public int getTajerNationalID() {
		return TajerNationalID;
	}
	public void setTajerNationalID(int tajerNationalID) {
		TajerNationalID = tajerNationalID;
	}
	public String getSourceCountry() {
		return SourceCountry;
	}
	public void setSourceCountry(String sourceCountry) {
		SourceCountry = sourceCountry;
	}
	public int getApproach() {
		return Approach;
	}
	public void setApproach(int approach) {
		Approach = approach;
	}
	public int getNumberOFStuffs() {
		return NumberOFStuffs;
	}
	public void setNumberOFStuffs(int numberOFStuffs) {
		NumberOFStuffs = numberOFStuffs;
	}
	public int getPriceOFStuffs() {
		return PriceOFStuffs;
	}
	public void setPriceOFStuffs(int priceOFStuffs) {
		PriceOFStuffs = priceOFStuffs;
	}
	
	
	
}
