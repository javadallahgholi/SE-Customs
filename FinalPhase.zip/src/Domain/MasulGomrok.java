package Domain;

import java.io.Serializable;

public class MasulGomrok implements Serializable {

	private static final long serialVersionUID = 1L;
	private int PersonnelID;
	private String FirstName;
	private String LastName;
	private String Post;
	
	public int getPersonnelID() {
		return PersonnelID;
	}
	public void setPersonnelID(int personnelID) {
		PersonnelID = personnelID;
	}
	public String getFirstName() {
		return FirstName;
	}
	public void setFirstName(String firstName) {
		FirstName = firstName;
	}
	public String getLastName() {
		return LastName;
	}
	public void setLastName(String lastName) {
		LastName = lastName;
	}
	public String getPost() {
		return Post;
	}
	public void setPost(String post) {
		Post = post;
	}
	
	public static long getSerialversionuid() {
		return serialVersionUID;
	}	
}