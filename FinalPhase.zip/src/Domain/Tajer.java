package Domain;

import java.util.HashSet;
import java.util.Set;

public class Tajer {
	
	private int tid;
	private String FirstName;
	private String LastName;
	private int SSID;
	private Set<License> License=new HashSet<License>();
	private Set<Ezharname> Ezharname=new HashSet<Ezharname>();
	
	public Tajer(){}
	
	public Tajer(String _FirstName,String _LastName,int _SSID){
		
		FirstName=_FirstName;
		LastName=_LastName;
		setSSID(_SSID);
	}

	public String getFirstName() {
		return FirstName;
	}
	public void setFirstName(String firstName) {
		FirstName = firstName;
	}
	public String getLastName() {
		return LastName;
	}
	public void setLastName(String lastName) {
		LastName = lastName;
	}
	
	public Set<License> getLicense() {
		return License;
	}
	public void setLicense(Set<License> license) {
		License = license;
	}

	public int getSSID() {
		return SSID;
	}

	public void setSSID(int sSID) {
		SSID = sSID;
	}

	public void addLicense(License l) {
		License.add(l);
		
	}

	public int getTid() {
		return tid;
	}

	public void setTid(int tid) {
		this.tid = tid;
	}

	public Set<Ezharname> getEzharname() {
		return Ezharname;
	}

	public void setEzharname(Set<Ezharname> ezharname) {
		Ezharname = ezharname;
	}

	public void addEzharnameh(Ezharname ezh) {
		Ezharname.add(ezh);
		
	}
	
	
	
}