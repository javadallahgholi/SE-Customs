package Domain;

public class Logininfo {
	
	private int id;
	private String UserName;
	private String Password;
	private int LoginType;
	private int VezaratType;
	
	Logininfo(){}; 
	
	Logininfo(String u,String p,int t){
		
		UserName=u;
		Password=p;
		LoginType=t;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getUserName() {
		return UserName;
	}
	public void setUserName(String userName) {
		UserName = userName;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}
	
	public int getLoginType() {
		return LoginType;
	}

	public void setLoginType(int loginType) {
		LoginType = loginType;
	}

	public int getVezaratType() {
		return VezaratType;
	}

	public void setVezaratType(int vezaratType) {
		VezaratType = vezaratType;
	}
	
}