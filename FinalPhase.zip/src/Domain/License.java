package Domain;

public class License {

	private int id;
	private String RegisterDate;
	private String ExpireDate;
	private String StuffName;
	private int Quantity;
	private int UnitPrice;
	private int UnitWeight;
	private String Company;
	private String SourceCountry;
	private int Type;
	private Tajer Tajer ;
	
	public License(){}
	
	public License(String _RegisterDate,String _ExpireDate, String _StuffName, int _Quantity, int _UnitPrice, int _UnitWeight, String _Company, String _SourceCountry,int _Type) {
		
		RegisterDate=_RegisterDate;
		ExpireDate=_ExpireDate;
		StuffName = _StuffName;
		Quantity = _Quantity;
		UnitPrice = _UnitPrice;
		UnitWeight = _UnitWeight;
		Company = _Company;
		SourceCountry = _SourceCountry;
		Type=_Type;
		
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getRegisterDate() {
		return RegisterDate;
	}

	public void setRegisterDate(String registerDate) {
		RegisterDate = registerDate;
	}

	public String getExpireDate() {
		return ExpireDate;
	}

	public void setExpireDate(String expireDate) {
		ExpireDate = expireDate;
	}

	public String getStuffName() {
		return StuffName;
	}

	public void setStuffName(String stuffName) {
		StuffName = stuffName;
	}

	public int getQuantity() {
		return Quantity;
	}

	public void setQuantity(int quantity) {
		Quantity = quantity;
	}

	public int getUnitPrice() {
		return UnitPrice;
	}

	public void setUnitPrice(int unitPrice) {
		UnitPrice = unitPrice;
	}

	public int getUnitWeight() {
		return UnitWeight;
	}

	public void setUnitWeight(int unitWeight) {
		UnitWeight = unitWeight;
	}

	public String getCompany() {
		return Company;
	}

	public void setCompany(String company) {
		Company = company;
	}

	public String getSourceCountry() {
		return SourceCountry;
	}

	public void setSourceCountry(String sourceCountry) {
		SourceCountry = sourceCountry;
	}

	public Tajer getTajer() {
		return Tajer;
	}

	public void setTajer(Tajer tajer) {
		Tajer = tajer;
	}

	public int getType() {
		return Type;
	}

	public void setType(int type) {
		Type = type;
	}

	
}