package Domain;

public class MasulVezaratkhane {
	
	int PersonnelID;
	String FirstName;
	String LastName;
	int VID;
	String Post;
	
	public int getPersonnelID() {
		return PersonnelID;
	}
	public void setPersonnelID(int personnelID) {
		PersonnelID = personnelID;
	}
	public String getFirstName() {
		return FirstName;
	}
	public void setFirstName(String firstName) {
		FirstName = firstName;
	}
	public String getLastName() {
		return LastName;
	}
	public void setLastName(String lastName) {
		LastName = lastName;
	}
	public int getVID() {
		return VID;
	}
	public void setVID(int vID) {
		VID = vID;
	}
	public String getPost() {
		return Post;
	}
	public void setPost(String post) {
		Post = post;
	}	
}