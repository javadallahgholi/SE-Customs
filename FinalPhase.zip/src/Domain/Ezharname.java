package Domain;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

public class Ezharname implements Serializable {
	

	private static final long serialVersionUID = -4358168883892032699L;
	private int ezid;
	private String Date;
	private String TajerName;
	private String TajerLastname;
	private int TajerNationalID;
	
	private MasulGomrok MasulGomrok;
	private Set<Stuff> Stuff=new HashSet<Stuff>();
	
	public Ezharname(){};
	
	public Ezharname(String _Date,String _TajerName,String _TajerLastname,int _TajerNationalID) {
		
		Date = _Date;
		TajerName = _TajerName;
		TajerLastname = _TajerLastname;
		TajerNationalID = _TajerNationalID;

	}

	public int getEzid() {
		return ezid;
	}

	public void setEzid(int ezid) {
		this.ezid = ezid;
	}

	public String getDate() {
		return Date;
	}

	public void setDate(String date) {
		Date = date;
	}

	public String getTajerName() {
		return TajerName;
	}

	public void setTajerName(String tajerName) {
		TajerName = tajerName;
	}

	public String getTajerLastname() {
		return TajerLastname;
	}

	public void setTajerLastname(String tajerLastname) {
		TajerLastname = tajerLastname;
	}

	public int getTajerNationalID() {
		return TajerNationalID;
	}

	public void setTajerNationalID(int tajerNationalID) {
		TajerNationalID = tajerNationalID;
	}

	public MasulGomrok getMasulGomrok() {
		return MasulGomrok;
	}

	public void setMasulGomrok(MasulGomrok masulGomrok) {
		MasulGomrok = masulGomrok;
	}

	public Set<Stuff> getStuff() {
		return Stuff;
	}

	public void setStuff(Set<Stuff> stuff) {
		this.Stuff = stuff;
	}
	
	public void addStuff(Stuff stuff){
		Stuff.add(stuff);
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((Date == null) ? 0 : Date.hashCode());
		result = prime * result
				+ ((MasulGomrok == null) ? 0 : MasulGomrok.hashCode());
		result = prime * result + ((Stuff == null) ? 0 : Stuff.hashCode());
		result = prime * result
				+ ((TajerLastname == null) ? 0 : TajerLastname.hashCode());
		result = prime * result
				+ ((TajerName == null) ? 0 : TajerName.hashCode());
		result = prime * result + TajerNationalID;
		result = prime * result + ezid;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Ezharname other = (Ezharname) obj;
		if (Date == null) {
			if (other.Date != null)
				return false;
		} else if (!Date.equals(other.Date))
			return false;
		if (MasulGomrok == null) {
			if (other.MasulGomrok != null)
				return false;
		} else if (!MasulGomrok.equals(other.MasulGomrok))
			return false;
		if (Stuff == null) {
			if (other.Stuff != null)
				return false;
		} else if (!Stuff.equals(other.Stuff))
			return false;
		if (TajerLastname == null) {
			if (other.TajerLastname != null)
				return false;
		} else if (!TajerLastname.equals(other.TajerLastname))
			return false;
		if (TajerName == null) {
			if (other.TajerName != null)
				return false;
		} else if (!TajerName.equals(other.TajerName))
			return false;
		if (TajerNationalID != other.TajerNationalID)
			return false;
		if (ezid != other.ezid)
			return false;
		return true;
	}

}
