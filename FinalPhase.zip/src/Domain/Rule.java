package Domain;

public class Rule {

	private int RuleID;
	private String FromDate;
	private String ToDate;
	private int FromUnitPrice;
	private int ToUnitPrice;
	private int FromUnitWeight;
	private int ToUnitWeight;
	private int MinStuffNumber;
	private int MaxStuffNumber;
	private String Stuffs;
	private String Companies;
	private String Mojavez;
	private int ApproachID;
	
	public Rule(){}
	
	public Rule(String FromDate_,String ToDate_,int FromUnitPrice_,int ToUnitPrice_,int FromUnitWeight_,int ToUnitWeight_,int MinStuffNumber_,int MaxStuffNumber_,String Stuffs_,String Companies_,String Mojavez_,int ApproachID_){
		
		FromDate=FromDate_;
		ToDate=ToDate_;
		FromUnitPrice=FromUnitPrice_;
		ToUnitPrice=ToUnitPrice_;
		FromUnitWeight=FromUnitWeight_;
		ToUnitWeight=ToUnitWeight_;
		MinStuffNumber=MinStuffNumber_;
		MaxStuffNumber=MaxStuffNumber_;
		Stuffs=Stuffs_;
		Companies=Companies_;
		Mojavez=Mojavez_;
		ApproachID=ApproachID_;
	}
	
	public int getRuleID() {
		return RuleID;
	}

	public void setRuleID(int ruleID) {
		RuleID = ruleID;
	}

	public String getFromDate() {
		return FromDate;
	}
	public void setFromDate(String fromDate) {
		FromDate = fromDate;
	}
	public String getToDate() {
		return ToDate;
	}
	public void setToDate(String toDate) {
		ToDate = toDate;
	}
	public int getFromUnitPrice() {
		return FromUnitPrice;
	}
	public void setFromUnitPrice(int fromUnitPrice) {
		FromUnitPrice = fromUnitPrice;
	}
	public int getToUnitPrice() {
		return ToUnitPrice;
	}
	public void setToUnitPrice(int toUnitPrice) {
		ToUnitPrice = toUnitPrice;
	}
	public int getFromUnitWeight() {
		return FromUnitWeight;
	}
	public void setFromUnitWeight(int fromUnitWeight) {
		FromUnitWeight = fromUnitWeight;
	}
	public int getToUnitWeight() {
		return ToUnitWeight;
	}
	public void setToUnitWeight(int toUnitWeight) {
		ToUnitWeight = toUnitWeight;
	}
	public String getStuffs() {
		return Stuffs;
	}
	public void setStuffs(String stuffs) {
		Stuffs = stuffs;
	}
	public String getCompanies() {
		return Companies;
	}
	public void setCompanies(String companies) {
		Companies = companies;
	}
	public String getMojavez() {
		return Mojavez;
	}
	public void setMojavez(String mojavez) {
		Mojavez = mojavez;
	}
	public int getApproachID() {
		return ApproachID;
	}
	public void setApproachID(int approachID) {
		ApproachID = approachID;
	}

	public int getMinStuffNumber() {
		return MinStuffNumber;
	}

	public void setMinStuffNumber(int minStuffNumber) {
		MinStuffNumber = minStuffNumber;
	}

	public int getMaxStuffNumber() {
		return MaxStuffNumber;
	}

	public void setMaxStuffNumber(int maxStuffNumber) {
		MaxStuffNumber = maxStuffNumber;
	}
}