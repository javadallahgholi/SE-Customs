package Domain;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

public class Stuff implements Serializable {
	
	private static final long serialVersionUID = -3249769191940966882L;
	private int Stuffid;
	private String StuffName;
	private int Quantity;
	private int Weight;
	private int UnitPrice;
	private String CompanyName;
	private String SourceCountry;
	private int ApproachID;
	private Set<Ezharname> Ezharname=new HashSet<Ezharname>();
	
	public Stuff(){}
	
	public Stuff(String _StuffName, int _Quantity, int _Weight, int _UnitPrice, String _CompanyName, String _SourceCountry, int _ApproachID){
		
		StuffName = _StuffName;
		Quantity = _Quantity;
		Weight = _Weight;
		UnitPrice = _UnitPrice;
		CompanyName = _CompanyName;
		SourceCountry = _SourceCountry;
		ApproachID = _ApproachID;
		
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ApproachID;
		result = prime * result
				+ ((CompanyName == null) ? 0 : CompanyName.hashCode());
		result = prime * result
				+ ((Ezharname == null) ? 0 : Ezharname.hashCode());
		result = prime * result + Quantity;
		result = prime * result
				+ ((SourceCountry == null) ? 0 : SourceCountry.hashCode());
		result = prime * result
				+ ((StuffName == null) ? 0 : StuffName.hashCode());
		result = prime * result + Stuffid;
		result = prime * result + UnitPrice;
		result = prime * result + Weight;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Stuff other = (Stuff) obj;
		if (ApproachID != other.ApproachID)
			return false;
		if (CompanyName == null) {
			if (other.CompanyName != null)
				return false;
		} else if (!CompanyName.equals(other.CompanyName))
			return false;
		if (Ezharname == null) {
			if (other.Ezharname != null)
				return false;
		} else if (!Ezharname.equals(other.Ezharname))
			return false;
		if (Quantity != other.Quantity)
			return false;
		if (SourceCountry == null) {
			if (other.SourceCountry != null)
				return false;
		} else if (!SourceCountry.equals(other.SourceCountry))
			return false;
		if (StuffName == null) {
			if (other.StuffName != null)
				return false;
		} else if (!StuffName.equals(other.StuffName))
			return false;
		if (Stuffid != other.Stuffid)
			return false;
		if (UnitPrice != other.UnitPrice)
			return false;
		if (Weight != other.Weight)
			return false;
		return true;
	}
	
	

	public int getStuffid() {
		return Stuffid;
	}

	public void setStuffid(int stuffid) {
		Stuffid = stuffid;
	}

	public String getStuffName() {
		return StuffName;
	}

	public void setStuffName(String stuffName) {
		StuffName = stuffName;
	}

	public int getQuantity() {
		return Quantity;
	}

	public void setQuantity(int quantity) {
		Quantity = quantity;
	}

	public int getWeight() {
		return Weight;
	}

	public void setWeight(int weight) {
		Weight = weight;
	}

	public int getUnitPrice() {
		return UnitPrice;
	}

	public void setUnitPrice(int unitPrice) {
		UnitPrice = unitPrice;
	}

	public String getCompanyName() {
		return CompanyName;
	}

	public void setCompanyName(String companyName) {
		CompanyName = companyName;
	}

	public String getSourceCountry() {
		return SourceCountry;
	}

	public void setSourceCountry(String sourceCountry) {
		SourceCountry = sourceCountry;
	}

	public int getApproachID() {
		return ApproachID;
	}

	public void setApproachID(int approachID) {
		ApproachID = approachID;
	}

	public Set<Ezharname> getEzharname() {
		return Ezharname;
	}

	public void setEzharname(Set<Ezharname> ezharname) {
		Ezharname = ezharname;
	}

}