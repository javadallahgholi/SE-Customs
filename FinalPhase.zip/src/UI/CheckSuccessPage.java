package UI;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class CheckSuccessPage {

public static void ShowSuccessPage(){
		
	final JFrame eframe = new JFrame("نمایش پیغام");
	eframe.setSize(210, 210);
	eframe.setLocationRelativeTo(null);
	JPanel epanel = new JPanel();
	eframe.add(epanel);
	epanel.setLayout(null);
        
	JLabel errorLabel = new JLabel("عملیات با موفقیت انجام شد !");
	errorLabel.setBounds(5, 40, 350, 25);
	epanel.add(errorLabel);
        
	JButton okButton = new JButton("خروج");
	okButton.setBounds(40, 100, 100, 25);
	epanel.add(okButton);
        
	okButton.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			
			eframe.dispose();     
		}
	});
	
	eframe.setVisible(true);
	
	}
}