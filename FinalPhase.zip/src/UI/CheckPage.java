package UI;

import DB.*;
import Domain.*;
import Bussiness.*;
import javax.swing.*;
import org.hibernate.Session;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CheckPage {
	
	public static  JTextField  CreateLable(JPanel panel,String name,int Lx,int Ly,
			int Lwidth,int Lheight,int Tx,int Ty,int Twidth,int Theight){
		
		JLabel Label = new JLabel(name);
        Label.setBounds(Lx, Ly,Lwidth,Lheight);
        panel.add(Label);
        JTextField Text = new JTextField(20);
        Text.setBounds(Tx, Ty,Twidth,Theight);
        panel.add(Text);
        return Text;
	}
	
    public static void show(boolean exitOnClose) {
    	
    	final JFrame frame = new JFrame("صفحه بررسی مجوز");
        frame.setSize(500, 350);
        frame.setLocationRelativeTo(null);
        
        if (exitOnClose)
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel();
        frame.add(panel);
        panel.setBackground(Color.LIGHT_GRAY);
        ImageImplement img = new ImageImplement(new ImageIcon("logo2.png").getImage());
        panel.add(img);
        img.setLocation(25, 15);

        JLabel Gomrok = new JLabel(" گمرک ");
        Gomrok.setBounds(120, 15,100,25);
        panel.add(Gomrok);
        JLabel Gomrok1 = new JLabel(" جمهوری اسلامی ");
        Gomrok1.setBounds(100, 35,100,25);
        panel.add(Gomrok1);
        JLabel Gomrok2 = new JLabel(" ایران ");
        Gomrok2.setBounds(120, 55,100,25);
        panel.add(Gomrok2);
        
        panel.setLayout(null);

        ////////////////////////////////////////////
        
        
        final JTextField ezharnamehIDText = CreateLable(panel, "شاسه اظهار نامه",395, 120, 150, 25, 280, 120, 100, 25);
        final JTextField licenseIDText = CreateLable(panel, "شناسه مجوز",150, 120, 150, 25, 35, 120, 100, 25);
        
        JButton registerButton = new JButton("بررسی");
        registerButton.setBounds(250, 240, 100, 25);
        panel.add(registerButton);
        
        JButton exitButton = new JButton("خروج");
        exitButton.setBounds(140, 240, 100, 25);
        panel.add(exitButton);
        
        exitButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                frame.dispose();     
                }
        });
        
        registerButton.addActionListener(new ActionListener() {
        	
            public void actionPerformed(ActionEvent e) {
            	
            	Session session=DBConnection.CreateSession();
                Ezharname ezh=(Ezharname)session.load(Ezharname.class, (Integer.parseInt(ezharnamehIDText.getText())-1)/2);
                License lic=(License)session.load(License.class, (Integer.parseInt(licenseIDText.getText())-1)/2);
            	
                Pair p = MapEzhtoLic.CheckError(ezh, lic);
                if(!p.getFirst())
                	MapEzhtoLic.MapandUpdate(ezh, lic, session, p);
                
            	frame.dispose();
            
            }
        });

        frame.setVisible(true);
    }

}