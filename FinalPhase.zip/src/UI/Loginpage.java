package UI;

import javax.swing.*;
import Bussiness.*;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Loginpage {
	
	public static void showNextPage(String Username,String Password){
		
		Pairr TypeOfPage = SearchforLogin.Search(Username, Password);
		
		if(TypeOfPage.getFirst()==0) LoginErrorPage.ShowLoginErrorPage();
		
		else if(TypeOfPage.getFirst()==1) GomrokMasoulPage.show(true);
		
		else if(TypeOfPage.getFirst()==2) VezaratMasoulPage.show(true,TypeOfPage.getSecond());
		
	}
	
	public static  JTextField  CreateLable(JPanel panel,String name,int Lx,
			int Ly,int Lwidth,int Lheight,int Tx,int Ty,int Twidth,int Theight){
		
		JLabel Label = new JLabel(name);
        Label.setBounds(Lx, Ly,Lwidth,Lheight);
        panel.add(Label);
        JTextField Text = new JTextField(20);
        Text.setBounds(Tx, Ty,Twidth,Theight);
        panel.add(Text);
        return Text;
	}
	
    public static void show(boolean exitOnClose) {
    	
        JFrame frame = new JFrame("صفحه ورود");
        frame.setSize(800, 300);
        frame.setLocationRelativeTo(null);
        if (exitOnClose)
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel();
        frame.add(panel);
        panel.setBackground(Color.GRAY);
        ImageImplement img = new ImageImplement(new ImageIcon("logo1.png").getImage());
        panel.add(img);
        img.setLocation(200, 0);
        
        panel.setLayout(null);
        final JTextField userNameText= CreateLable(panel, "نام کاربری :", 450, 100, 350, 25, 330, 100, 100, 25);
        final JTextField passwordText= CreateLable(panel, "شناسه عبور :", 450, 150, 80, 25, 330, 150, 100, 25);
        
        
        JButton submitButton = new JButton("ورود");
        submitButton.setBounds(305, 200, 150, 25);
        panel.add(submitButton);

          
        submitButton.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {
            	
                String Username = userNameText.getText();
                userNameText.setText("");  
                String Password = passwordText.getText();
                passwordText.setText("");
        		showNextPage(Username,Password);
        	    
            }
        });
        
        frame.setVisible(true);
     
    }	
}