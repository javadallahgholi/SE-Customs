package UI;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class CheckErrorPage {

public static void ShowErrorPage(int error){
		
	final JFrame eframe = new JFrame("خطا");
	eframe.setSize(220, 210);
	eframe.setLocationRelativeTo(null);
	JPanel epanel = new JPanel();
	eframe.add(epanel);
	epanel.setLayout(null);
	//Tajer Error
	if(error ==  1){
        ImageImplement img = new ImageImplement(new ImageIcon("logo5.png").getImage());
        epanel.add(img);
        img.setLocation(80, 10);
		JLabel errorLabel = new JLabel("تاجر مجوز و اظهارنامه با یکدیگر همخوانی ندارد!");
		errorLabel.setFont(new Font("Arial", Font.BOLD | Font.CENTER_BASELINE, 12));
		errorLabel.setBounds(5, 75, 350, 25);
		epanel.add(errorLabel);
        
		JButton okButton = new JButton("خروج");
		okButton.setBounds(55, 120, 100, 25);
		epanel.add(okButton);        
		okButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			
				eframe.dispose();     
			}
		});
	}
	
	//Date Error
	if(error ==  2){
        ImageImplement img = new ImageImplement(new ImageIcon("logo5.png").getImage());
        epanel.add(img);
        img.setLocation(80, 10);
		JLabel errorLabel = new JLabel("مجوز منقضی شده است! ");
		errorLabel.setFont(new Font("Arial", Font.BOLD | Font.CENTER_BASELINE, 15));
		errorLabel.setBounds(45, 75, 350, 25);
		epanel.add(errorLabel);
        
		JButton okButton = new JButton("خروج");
		okButton.setBounds(55, 120, 100, 25);
		epanel.add(okButton);        
		okButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			
				eframe.dispose();     
			}
		});
	}
	
	//Quantity Error
	if(error ==  3){
        ImageImplement img = new ImageImplement(new ImageIcon("logo5.png").getImage());
        epanel.add(img);
        img.setLocation(80, 10);
		JLabel errorLabel = new JLabel("مقادیر وارد شده از سقف مجاز بیشتر است! ");
		errorLabel.setFont(new Font("Arial", Font.BOLD | Font.CENTER_BASELINE, 13));
		errorLabel.setBounds(5, 75, 350, 25);
		epanel.add(errorLabel);
        
		JButton okButton = new JButton("خروج");
		okButton.setBounds(55, 120, 100, 25);
		epanel.add(okButton);        
		okButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			
				eframe.dispose();     
			}
		});
	}
	
	//Company Error
	if(error ==  4){
        ImageImplement img = new ImageImplement(new ImageIcon("logo5.png").getImage());
        epanel.add(img);
        img.setLocation(80, 10);
        
		JLabel errorLabel = new JLabel("شرکت های وارد شده در اظهارنامه با مجوز همخوانی ندارد!");
		errorLabel.setFont(new Font("Arial", Font.BOLD | Font.CENTER_BASELINE, 12));
		errorLabel.setBounds(5, 75, 350, 25);
		epanel.add(errorLabel);
        
		JButton okButton = new JButton("خروج");
		okButton.setBounds(55, 120, 100, 25);
		epanel.add(okButton);        
		okButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			
				eframe.dispose();     
			}
		});
	}
	
	//Country Error
	if(error ==  5){
        ImageImplement img = new ImageImplement(new ImageIcon("logo5.png").getImage());
        epanel.add(img);
        img.setLocation(80, 10);
        
		JLabel errorLabel = new JLabel("کشورهای وارد شده در اظهارنامه با مجوز همخوانی ندارد!");
		errorLabel.setFont(new Font("Arial", Font.BOLD | Font.CENTER_BASELINE, 12));
		errorLabel.setBounds(5, 75, 350, 25);
		epanel.add(errorLabel);
        
		JButton okButton = new JButton("خروج");
		okButton.setBounds(55, 120, 100, 25);
		epanel.add(okButton);        
		okButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			
				eframe.dispose();     
			}
		});
	}
	
	eframe.setVisible(true);
	
	}
}