package UI;

import DB.*;
import Domain.*;
import Bussiness.*;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import javax.swing.*;
import org.hibernate.Session;

public class WaitPage {
	
	private static Timer timer;
	
	public static void show(boolean exitOnClose, int LastezID) {
			
		List<String> Licenselist = new ArrayList<>();
		final List<String> Sendlist=new ArrayList<>();
		
		final JFrame framewait = new JFrame(" پیغام ");
		framewait.setSize(250, 150);
		framewait.setLocationRelativeTo(null);
	
		if (exitOnClose)
			framewait.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			        
		JPanel panel = new JPanel();
		framewait.add(panel);
		panel.setBackground(Color.LIGHT_GRAY);
				
		JLabel a = new JLabel("      ");
		a.setBounds(20, 00, 100, 25);
		panel.add(a);
			        
		JLabel Msg = new JLabel(" سیستم در حال بررسی مجوز های اظهارنامه می باشد. ");
		Msg.setBounds(10, 200,500,25);
		panel.add(Msg);
				
		JLabel Wait = new JLabel(" لطفا کمی صبر کنید ... ");
		Wait.setBounds(70, 250,100,25);
		panel.add(Wait);
				
		ImageImplement img = new ImageImplement(new ImageIcon("logo4.jpg").getImage());
		panel.add(img);
		img.setLocation(220, 10);
		
		Session session=DBConnection.CreateSession();
    	Ezharname Lastez=(Ezharname)session.get(Ezharname.class, LastezID);
    	Licenselist=CheckLicense.GetLicense(Lastez);
				
		for(String s:Licenselist)
			Sendlist.add(s);
				
		ActionListener action = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
	
				framewait.dispose();
				ShowLicencePage.show(true, Sendlist,LastezID);	
				timer.stop();
			}
		};
		
		timer = new Timer(1000, action);
		timer.start();
		               
		framewait.setVisible(true);

	}	
}
