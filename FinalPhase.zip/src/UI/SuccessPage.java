package UI;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class SuccessPage {

public static void ShowSuccessLicense(int lastLicID){
		
	final JFrame eframe = new JFrame("نمایش پیغام");
	eframe.setSize(220, 210);
	eframe.setLocationRelativeTo(null);
	JPanel epanel = new JPanel();
	eframe.add(epanel);
	epanel.setLayout(null);
        
	JLabel succLabel = new JLabel("عملیات با موفقیت انجام شد !");
	succLabel.setFont(new Font("Arial", Font.BOLD | Font.CENTER_BASELINE, 15));
	succLabel.setBounds(33, 20, 350, 25);
	epanel.add(succLabel);
	
	JLabel receiptLabel = new JLabel("شماره رسید : ");
	receiptLabel.setFont(new Font("Arial", Font.BOLD | Font.CENTER_BASELINE, 18));
	receiptLabel.setBounds(80, 65, 350, 25);
	JLabel titleLabel = new JLabel(Integer.toString((lastLicID*2)+1));
	titleLabel.setFont(new Font("Arial", Font.BOLD | Font.CENTER_BASELINE, 18));
	titleLabel.setBounds(50, 65, 350, 25);
	epanel.add(receiptLabel);
	epanel.add(titleLabel);

        
	JButton okButton = new JButton("خروج");
	okButton.setBounds(55, 120, 100, 25);
	epanel.add(okButton);
        
	okButton.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			
			eframe.dispose();     
		}
	});
	
	eframe.setVisible(true);
	
	}
}