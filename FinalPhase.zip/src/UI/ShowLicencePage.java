package UI;

import java.awt.*;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class ShowLicencePage {
	
	public static JLabel[] createLabels(List<String> list){
		
		JLabel[] labels = new JLabel[list.size()];
		for(int i = 0; i < list.size(); i++)
			labels[i] = new JLabel(list.get(i));
		return labels;
    }
	
	public static void show(boolean exitOnClose, List<String> list,int LastezID) {

		final JFrame frame = new JFrame(" نمایش مجوزها ");
		frame.setSize(400, 400);
		frame.setLocationRelativeTo(null);
		if (exitOnClose)
			frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	      
		JLabel[] labels = createLabels(list);
		JPanel panel = new JPanel();
		frame.add(panel);
		panel.setBackground(Color.LIGHT_GRAY);
		ImageImplement img = new ImageImplement(new ImageIcon("logo2.png").getImage());
		panel.add(img);
		img.setLocation(160, 15);

		JLabel Gomrok = new JLabel(" گمرک ");
		Gomrok.setBounds(230, 100,100,25);
		panel.add(Gomrok);
		JLabel Gomrok1 = new JLabel(" جمهوری اسلامی ");
		Gomrok1.setBounds(160, 100,100,25);
		panel.add(Gomrok1);
		JLabel Gomrok2 = new JLabel(" ایران ");
		Gomrok2.setBounds(135, 100,100,25);
		panel.add(Gomrok2);
		panel.setLayout(null);
	      
		JLabel Desc1 = new JLabel(" این اظهارنامه نیازمند مجوز های زیر می باشد : ");
		Desc1.setBounds(80, 135, 300, 30);
		panel.add(Desc1);
		Desc1.setFont(new Font("Arial", Font.BOLD | Font.CENTER_BASELINE, 15));
		
		JLabel ezID = new JLabel(" شماره شناسه اظهارنامه : ");
		ezID.setBounds(80, 255, 300, 30);
		panel.add(ezID);
		ezID.setFont(new Font("Arial", Font.BOLD | Font.CENTER_BASELINE, 13));
		
		
		JLabel ezID1 = new JLabel(Integer.toString(2*LastezID+1));
		ezID1.setBounds(125, 275, 300, 30);
		panel.add(ezID1);
		ezID1.setFont(new Font("Arial", Font.BOLD | Font.CENTER_BASELINE, 13));
	    
	      
		int x = 140;
		int y = 170;
		for (int i=0;i<labels.length;i++){
	    	  
			labels[i].setBounds(x, y, 200, 25);
			panel.add(labels[i]);
			y+=25;	
		}
  
		JButton exitButton = new JButton("خروج");
		exitButton.setBounds(125, 300, 150, 25);
		panel.add(exitButton);
	        
		exitButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
	               
				frame.dispose();     
			}
		});
	      
		frame.setVisible(true);  
	  }
}