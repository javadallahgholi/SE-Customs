package Test;

import java.util.List;
import UI.CheckSuccessPage;
import Bussiness.*;
import Domain.*;

public class IntegrationTest {
	
	public static void GetLicenseTest(){
		
		Ezharname e=new Ezharname( "2016/6/20", "mahmud reza", "hashemi", 431);
		Stuff s1=new Stuff("fulad", 200, 300, 100, "zobahan", "canada", 2);
		Stuff s2=new Stuff("ampul", 500, 600, 50, "darusazan", "usa", 0);
		e.addStuff(s1);
		e.addStuff(s2);
		
		List<String> l=CheckLicense.GetLicense(e);
		for(String s:l)
			System.out.println(s);
	}

	public static void MapEzhtoLicTest(){
		
		Tajer tajer=new Tajer("mahmud reza","hashemi",431);
		License lic = new License("2015/1/1", "2019/5/20", "milgerd", 1156, 100, 50, "zobahan", "canada", 1);
		lic.setTajer(tajer);
		
		Stuff stuff =  new Stuff("milgerd",156,10,50,"zobahan","canada",1);
		Ezharname ezharname=new Ezharname( "2016/6/20", "mahmud reza", "hashemi", 431);
		ezharname.addStuff(stuff);
		int p=stuff.getQuantity();
		lic.setQuantity(lic.getQuantity()-p);
		System.out.println(lic.getQuantity());
    	CheckSuccessPage.ShowSuccessPage();
	}
}