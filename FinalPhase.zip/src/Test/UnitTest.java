
package Test;

import Bussiness.*;
import Domain.*;

public class UnitTest {
	
	public static void SplitterTest(){
		
		String s="ali-hasan-hosein";
		String[] result=Operations.splitter(s);
		
		for (String st:result)
			System.out.println(st);
	}

	public static void CompareTest(){
		
		String s1="1395/1/1";
		String s2="1396/1/1";
		System.out.println(Operations.compareDate(s1, s2));
		System.out.println(Operations.compareDate(s2, s1));
		System.out.println(Operations.compareDate(s2, s2));
	}

	public static void CheckTest(){
		
		Rule r = new Rule("2014/5/20", "2019/9/15", 50, 500, 200, 1000, 100, 1000, "fulad-milgerd-tirahan", "zobahan", "3", 2);
			
		System.out.println("Date Boundry");
		System.out.println(CheckLicense.check(new Ezharname( "2016/6/20", "mahmud reza", "hashemi", 431), new Stuff("fulad", 200, 300, 100, "zobahan", "canada", 2), r));
		System.out.println(CheckLicense.check(new Ezharname( "2013/1/1", "mahmud reza", "hashemi", 431), new Stuff("fulad", 200, 300, 100, "zobahan", "canada", 2), r));
		System.out.println(CheckLicense.check(new Ezharname( "2020/1/1", "mahmud reza", "hashemi", 431), new Stuff("fulad", 200, 300, 100, "zobahan", "canada", 2), r));
		System.out.println(CheckLicense.check(new Ezharname( "2014/5/20", "mahmud reza", "hashemi", 431), new Stuff("fulad", 200, 300, 100, "zobahan", "canada", 2), r));
		System.out.println(CheckLicense.check(new Ezharname( "2019/9/15", "mahmud reza", "hashemi", 431), new Stuff("fulad", 200, 300, 100, "zobahan", "canada", 2), r));
		
		System.out.println("Quantity Boundry");
		System.out.println(CheckLicense.check(new Ezharname( "2016/6/20", "mahmud reza", "hashemi", 431), new Stuff("fulad", 200, 300, 100, "zobahan", "canada", 2), r));
		System.out.println(CheckLicense.check(new Ezharname( "2016/6/20", "mahmud reza", "hashemi", 431), new Stuff("fulad", 50, 300, 100, "zobahan", "canada", 2), r));
		System.out.println(CheckLicense.check(new Ezharname( "2016/6/20", "mahmud reza", "hashemi", 431), new Stuff("fulad", 1500, 300, 100, "zobahan", "canada", 2), r));
		System.out.println(CheckLicense.check(new Ezharname( "2016/6/20", "mahmud reza", "hashemi", 431), new Stuff("fulad", 100, 300, 100, "zobahan", "canada", 2), r));
		System.out.println(CheckLicense.check(new Ezharname( "2016/6/20", "mahmud reza", "hashemi", 431), new Stuff("fulad", 1000, 300, 100, "zobahan", "canada", 2), r));
		
		System.out.println("Price Boundry");
		System.out.println(CheckLicense.check(new Ezharname( "2016/6/20", "mahmud reza", "hashemi", 431), new Stuff("fulad", 200, 300, 100, "zobahan", "canada", 2), r));
		System.out.println(CheckLicense.check(new Ezharname( "2016/6/20", "mahmud reza", "hashemi", 431), new Stuff("fulad", 50, 300, 20, "zobahan", "canada", 2), r));
		System.out.println(CheckLicense.check(new Ezharname( "2016/6/20", "mahmud reza", "hashemi", 431), new Stuff("fulad", 1500, 300, 600, "zobahan", "canada", 2), r));
		System.out.println(CheckLicense.check(new Ezharname( "2016/6/20", "mahmud reza", "hashemi", 431), new Stuff("fulad", 100, 300, 50, "zobahan", "canada", 2), r));
		System.out.println(CheckLicense.check(new Ezharname( "2016/6/20", "mahmud reza", "hashemi", 431), new Stuff("fulad", 1000, 300, 500, "zobahan", "canada", 2), r));
		
		System.out.println("Weight Boundry");
		System.out.println(CheckLicense.check(new Ezharname( "2016/6/20", "mahmud reza", "hashemi", 431), new Stuff("fulad", 200, 300, 100, "zobahan", "canada", 2), r));
		System.out.println(CheckLicense.check(new Ezharname( "2016/6/20", "mahmud reza", "hashemi", 431), new Stuff("fulad", 50, 50, 100, "zobahan", "canada", 2), r));
		System.out.println(CheckLicense.check(new Ezharname( "2016/6/20", "mahmud reza", "hashemi", 431), new Stuff("fulad", 1500, 1200, 100, "zobahan", "canada", 2), r));
		System.out.println(CheckLicense.check(new Ezharname( "2016/6/20", "mahmud reza", "hashemi", 431), new Stuff("fulad", 100, 200, 100, "zobahan", "canada", 2), r));
		System.out.println(CheckLicense.check(new Ezharname( "2016/6/20", "mahmud reza", "hashemi", 431), new Stuff("fulad", 1000, 1000, 100, "zobahan", "canada", 2), r));
		
		System.out.println("Other Boundry");
		System.out.println(CheckLicense.check(new Ezharname( "2016/6/20", "mahmud reza", "hashemi", 431), new Stuff("ampul", 200, 300, 100, "zobahan", "canada", 2), r));
		System.out.println(CheckLicense.check(new Ezharname( "2016/6/20", "mahmud reza", "hashemi", 431), new Stuff("fulad", 50, 300, 100, "esteghlal", "canada", 2), r));
		System.out.println(CheckLicense.check(new Ezharname( "2016/6/20", "mahmud reza", "hashemi", 431), new Stuff("fulad", 1500, 300, 100, "zobahan", "canada", 1), r));
		
	}
		
	public static void CheckErrorTest(){
		
		Tajer tajer=new Tajer("mahmud reza","hashemi",431);
		License lic = new License("2015/1/1", "2019/5/20", "milgerd", 200, 100, 50, "zobahan", "canada", 1);
		lic.setTajer(tajer);
		
		Stuff stuff =  new Stuff("milgerd",100,10,50,"zobahan","canada",1);
		Ezharname ezharname=new Ezharname( "2016/6/20", "mahmud reza", "hashemi", 431);
		ezharname.addStuff(stuff);
		System.out.println(MapEzhtoLic.CheckError(ezharname,lic).getFirst());
		
		Stuff stuff2 =  new Stuff("milgerd",100,10,50,"zobahan","canada",1);
		Ezharname ezharname2=new Ezharname( "2016/6/20", "mahmud reza", "hashemi", 432);
		ezharname2.addStuff(stuff2);
		System.out.println(MapEzhtoLic.CheckError(ezharname2,lic).getFirst());
		
		Stuff stuff3 =  new Stuff("milgerd",100,10,50,"zobahan","canada",1);
		Ezharname ezharname3=new Ezharname( "2014/6/20", "mahmud reza", "hashemi", 431);
		ezharname3.addStuff(stuff3);
		System.out.println(MapEzhtoLic.CheckError(ezharname3,lic).getFirst());
		
		Stuff stuff4 =  new Stuff("milgerd",100,10,50,"zobahan","canada",1);
		Ezharname ezharname4=new Ezharname( "2020/6/20", "mahmud reza", "hashemi", 431);
		ezharname4.addStuff(stuff4);
		System.out.println(MapEzhtoLic.CheckError(ezharname4,lic).getFirst());
		
		Stuff stuff5 =  new Stuff("milgerd",100,10,50,"zobahan","canada",1);
		Ezharname ezharname5=new Ezharname( "2019/5/20", "mahmud reza", "hashemi", 431);
		ezharname5.addStuff(stuff5);
		System.out.println(MapEzhtoLic.CheckError(ezharname5,lic).getFirst());
		
		Stuff stuff6 =  new Stuff("milgerd",100,10,50,"zobahan","canada",1);
		Ezharname ezharname6=new Ezharname( "2015/1/1", "mahmud reza", "hashemi", 431);
		ezharname6.addStuff(stuff6);
		System.out.println(MapEzhtoLic.CheckError(ezharname6,lic).getFirst());
		
		Stuff stuff7 =  new Stuff("ferez",100,10,50,"zobahan","canada",1);
		Ezharname ezharname7=new Ezharname( "2016/6/20", "mahmud reza", "hashemi", 431);
		ezharname7.addStuff(stuff7);
		System.out.println(MapEzhtoLic.CheckError(ezharname7,lic).getFirst());
		
		Stuff stuff8 =  new Stuff("milgerd",100,10,200,"zobahan","canada",1);
		Ezharname ezharname8=new Ezharname( "2016/6/20", "mahmud reza", "hashemi", 431);
		ezharname8.addStuff(stuff8);
		System.out.println(MapEzhtoLic.CheckError(ezharname8,lic).getFirst());
		
		Stuff stuff9 =  new Stuff("milgerd",100,100,50,"zobahan","canada",1);
		Ezharname ezharname9=new Ezharname( "2016/6/20", "mahmud reza", "hashemi", 431);
		ezharname9.addStuff(stuff9);
		System.out.println(MapEzhtoLic.CheckError(ezharname9,lic).getFirst());
		
		Stuff stuff10 =  new Stuff("milgerd",1000,10,50,"zobahan","canada",1);
		Ezharname ezharname10=new Ezharname( "2016/6/20", "mahmud reza", "hashemi", 431);
		ezharname10.addStuff(stuff10);
		System.out.println(MapEzhtoLic.CheckError(ezharname10,lic).getFirst());
		
		Stuff stuff11 =  new Stuff("milgerd",100,50,50,"zobahan","canada",1);
		Ezharname ezharname11=new Ezharname( "2016/6/20", "mahmud reza", "hashemi", 431);
		ezharname11.addStuff(stuff11);
		System.out.println(MapEzhtoLic.CheckError(ezharname11,lic).getFirst());
		
		Stuff stuff12 =  new Stuff("milgerd",100,10,100,"zobahan","canada",1);
		Ezharname ezharname12=new Ezharname( "2016/6/20", "mahmud reza", "hashemi", 431);
		ezharname12.addStuff(stuff12);
		System.out.println(MapEzhtoLic.CheckError(ezharname12,lic).getFirst());
		
		Stuff stuff13 =  new Stuff("milgerd",200,10,50,"zobahan","canada",1);
		Ezharname ezharname13=new Ezharname( "2016/6/20", "mahmud reza", "hashemi", 431);
		ezharname13.addStuff(stuff13);
		System.out.println(MapEzhtoLic.CheckError(ezharname13,lic).getFirst());
		
		Stuff stuff14 =  new Stuff("milgerd",100,10,50,"foolad mobarake","canada",1);
		Ezharname ezharname14=new Ezharname( "2016/6/20", "mahmud reza", "hashemi", 431);
		ezharname14.addStuff(stuff14);
		System.out.println(MapEzhtoLic.CheckError(ezharname14,lic).getFirst());
		
		Stuff stuff15 =  new Stuff("milgerd",100,10,50,"zobahan","england",1);
		Ezharname ezharname15=new Ezharname( "2016/6/20", "mahmud reza", "hashemi", 431);
		ezharname15.addStuff(stuff15);
		System.out.println(MapEzhtoLic.CheckError(ezharname15,lic).getFirst());
	}

}