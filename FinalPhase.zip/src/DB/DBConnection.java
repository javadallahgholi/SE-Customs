package DB;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import Domain.*;

public class DBConnection {
	
	public static Session CreateSession(){
		
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		
		return session;
	}
	
	public static void CloseSession(Session session){
		
		session.close();
	}
	
	public static <T> void Insert(T istance,Session session){
		
		session.save(istance);
		session.getTransaction().commit();
		CloseSession(session);
		
	}
	
	public static <T> void Update(T istance,Session session){
		
		session.update(istance);
		session.getTransaction().commit();
		CloseSession(session);
		
	}
		
	public static List InsertQuery(String Query){
		
		Session session = DBConnection.CreateSession();
		Query q = session.createQuery(Query);
	    List list = ((org.hibernate.Query) q).list();
	    
	    return list;
	}

}