package Bussiness;

import java.util.*;

import DB.*;
import Domain.*;

import org.hibernate.Session;

public class CheckLicense {
	
	public static boolean check(Ezharname e, Stuff s, Rule r){
		
		String[] stuffs = Operations.splitter(r.getStuffs());
		boolean stuffFlag = false;
		
		for(int i = 0; i < stuffs.length ; i++){
			if(stuffs[i].equals(s.getStuffName()))
				stuffFlag = true;
		}
		
		if( !(r.getFromDate().equals("")) && !(r.getToDate().equals("")) )
			if(Operations.compareDate(e.getDate(), r.getFromDate())==-1 || Operations.compareDate(e.getDate(), r.getToDate())==1)
				return false;
		
		if(r.getFromUnitPrice()>0 && r.getToUnitPrice()>0)
			if(s.getUnitPrice() < r.getFromUnitPrice() || s.getUnitPrice() > r.getToUnitPrice())
				return false;
		
		if(r.getFromUnitWeight()>0 && r.getToUnitWeight()>0)
			if(s.getWeight() < r.getFromUnitWeight() || s.getWeight() > r.getToUnitWeight())
				return false;
		
		if(r.getMinStuffNumber()>0 && r.getMaxStuffNumber()>0)
			if(s.getQuantity() < r.getMinStuffNumber() || s.getQuantity() > r.getMaxStuffNumber())
				return false;
		
		if(!stuffFlag)
			return false;
		
		if( r.getApproachID() != s.getApproachID())
			return false;
		
		if(!(r.getCompanies().equals("")))
			if(!(s.getCompanyName().equals(r.getCompanies())))
				return false;
		
		return true;
		
	}
	
	public static List<String> GetLicense(Ezharname e){
		
		List<String> LicID = new ArrayList<>();
		Set<Stuff> a = new HashSet<Stuff>();
		a = e.getStuff();
		Session session=DBConnection.CreateSession();
		List<Rule> l=session.createCriteria(Rule.class).list();
			
			for(Rule r : l)
				for(Stuff s : a)
					if(check(e,s,r)){
						LicID.add(r.getMojavez());
				}
		
		return LicID;
		
	}

}