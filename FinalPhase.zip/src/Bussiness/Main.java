package Bussiness;

import Test.*;
import UI.*;

public class Main {

    public static void main(String[] args) {
    	
    	//project
    	
    	//Loginpage.show(true);
    	//CheckPage.show(true);
    	//LicensePage.show(true,1);
    	//NewRulePage.show(true);
    	EzharNamehPage.show(true);
    	//VezaratMasoulPage.show(true);
    	//GomrokMasoulPage.show(true);	
    	//Ezharname ezh = new Ezharname(); 
    	//WaitPage.show(true, ezh);
    	
    	
    	//tests
    	
    	//UnitTest.SplitterTest();
    	//UnitTest.CompareTest();
    	//UnitTest.CheckTest();
    	//IntegrationTest.GetLicenseTest();
    	//UnitTest.CheckErrorTest();
    	//IntegrationTest.MapEzhtoLicTest();
    }
}