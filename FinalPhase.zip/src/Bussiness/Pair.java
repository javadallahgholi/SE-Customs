package Bussiness;

public class Pair {
	
    private final boolean first;
    private final int second;

    public Pair(boolean first, int second) {
        this.first = first;
        this.second = second;
    }

    public boolean getFirst() {
        return first;
    }

    public int getSecond() {
        return second;
    }
}