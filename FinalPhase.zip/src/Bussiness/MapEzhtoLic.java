package Bussiness;

import org.hibernate.Session;

import UI.CheckErrorPage;
import UI.CheckSuccessPage;
import DB.DBConnection;
import Domain.Ezharname;
import Domain.License;
import Domain.Stuff;

public class MapEzhtoLic {
	
	public static Pair CheckError(Ezharname ezh,License lic){
		
		boolean errorflag=false;
	
        if(!(ezh.getTajerNationalID()==lic.getTajer().getSSID())){
        	CheckErrorPage.ShowErrorPage(1);
        	errorflag=true; 	
        }
        	
        if(!errorflag)
	        if(Operations.compareDate(ezh.getDate(),lic.getRegisterDate())==-1||Operations.compareDate(ezh.getDate(),lic.getExpireDate())==1){
	        	CheckErrorPage.ShowErrorPage(2);
	        	errorflag=true;
	        }
        
        int qtemp=-1;
        if(!errorflag)
            for(Stuff s:ezh.getStuff())
            	if(s.getStuffName().equals(lic.getStuffName())){
           
            		qtemp=s.getQuantity();
            		if( s.getQuantity() > lic.getQuantity() || s.getUnitPrice() > lic.getUnitPrice() || s.getWeight() > lic.getUnitWeight()){
            			CheckErrorPage.ShowErrorPage(3);
            			errorflag=true;
            		}
            		
            		else if (!(s.getCompanyName().equals(lic.getCompany()))){
            			CheckErrorPage.ShowErrorPage(4);
            			errorflag=true;
            		}
            		
            		else if (!(s.getSourceCountry().equals(lic.getSourceCountry()))){
            			CheckErrorPage.ShowErrorPage(5);
            			errorflag=true;
            		}
				}
        if( qtemp==-1)
        	errorflag=true;
        
        return new Pair(errorflag, qtemp);
	}

	public static void MapandUpdate(Ezharname ezh,License lic,Session session,Pair p){
		
		lic.setQuantity(lic.getQuantity()-p.getSecond());
    	DBConnection.Update(lic,session);
    	CheckSuccessPage.ShowSuccessPage();
	}

}