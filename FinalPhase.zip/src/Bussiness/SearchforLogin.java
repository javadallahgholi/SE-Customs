package Bussiness;

import java.util.List;

import DB.DBConnection;
import Domain.Logininfo;

public class SearchforLogin {

	public static Pairr Search(String Username,String Password){
		
		boolean FindUserFlag=false;
		int LoginType=-1;
		int VezaratType=-1;
		
		List<Logininfo> list=DBConnection.InsertQuery("FROM Logininfo");
	   
	    if(list.size() != 0){
	    	
	    	for(Logininfo li:list){
	    		
	    		if(li.getUserName().equals(Username) && li.getPassword().equals(Password)){
		        	FindUserFlag=true;
		        	LoginType = li.getLoginType();
		        	VezaratType=li.getVezaratType();
		        	
	        	}
	    	}
	    }
	    
	    else System.out.println("No records exist");
		
	    if(FindUserFlag == true && LoginType==1)
	    	return new Pairr(1, VezaratType);
	    
	    else if(FindUserFlag == true && LoginType==2)
	    	return new Pairr(2, VezaratType);
	    
	    else
	    	return new Pairr(0, 0);
	}

}